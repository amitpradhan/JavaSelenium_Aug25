//
//
//
//import static io.cucumber.core.options.Constants.GLUE_PROPERTY_NAME;
//import static io.cucumber.core.options.Constants.FEATURES_PROPERTY_NAME;
//
//@Suite
//@IncludeEngines("cucumber")
//@SelectClasspathResource("features") // Assuming your feature files are in the 'features' directory on the classpath
//@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.example.stepdefs") // Replace with your actual glue path
//
//public class TestRunner {
//
//}
//
//
