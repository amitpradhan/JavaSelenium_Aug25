package com.automation.day6.testng_start;

import org.testng.annotations.Test;

public class Testng_test1 {


   @Test
   public void testcaseOne(){
       System.out.println("Test case one..");
   }

    @Test
    public void testcaseTwo(){
        System.out.println("Test case two..");
    }



}
