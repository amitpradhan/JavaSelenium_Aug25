package com.automation.utils;

import org.openqa.selenium.WebDriver;

public class BaseAutomationExcercise {
    public static WebDriver driver;
    public static int existingNoOfItemsInCart;

}
